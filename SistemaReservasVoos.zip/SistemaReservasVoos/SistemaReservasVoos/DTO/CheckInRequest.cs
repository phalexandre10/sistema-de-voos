﻿namespace SistemaReservasVoos.DTO
{
    public class CheckInRequest
    {
        public int ReservaId { get; set; }
        public string NumeroAssento { get; set; }
    }
}
